import React from 'react'
import PropTypes from 'prop-types'
import { Modal, Form, Input, Row, Button } from 'antd'
import { request, config } from 'utils'

import PostModal from './postModal.js'
import styles from './index.less'

const { api } = config

const FormItem = Form.Item

class ModalLogin extends React.Component {
  state = {
    confirmLoading: false,
    PostVisible: false, // 显示角色选择
    posts: [], // 角色列表
  }

  getUserPost = () => {
    request(api.user).then((json) => {
      if (json.data.posts.length === 1) {
        this.selectPost({ postId: json.data.posts[0].postId })
      } else if (json.data.posts.length > 1) {
        this.setState({
          PostVisible: true,
          posts: json.data.posts,
        })
      } else {
        const errorMessage = { message: '用户岗位信息错误！请联系管理员' }
        throw errorMessage
      }
    })
  }
  closeModal = () => {
    this.setState({ PostVisible: false })
  }
  handleOk = () => {
    const { validateFieldsAndScroll } = this.props.form
    validateFieldsAndScroll((errors, values) => {
      if (errors) {
        return
      }
      this.setState({
        confirmLoading: true,
      })
      sessionStorage.isvisited = 'yes'
      request(api.userLogin, {
        body: JSON.stringify(values),
        showMsg: false,
      }).then((json) => {
        setTimeout(() => {
          this.setState({
            confirmLoading: false,
          })
          if (json.success) {
            this.getUserPost()
          }
        }, 100)
      })
      // dispatch({ type: 'login/login', payload: values })
    })
  }
  handlePostModal = (payload) => {
    if (payload.postId) {
      this.selectPost(payload)
    } else {
      this.closeModal()
    }
  }
  selectPost = (data) => {
    const { dispatch } = this.props
    request(api.switchPost, {
      body: JSON.stringify({ postId: data.postId }),
      showMsg: false,
    }).then((json) => {
      if (json.success && json.data) {
        sessionStorage.postName = data.postName
        this.closeModal()
        dispatch({ type: 'app/query' })
        dispatch({ type: 'app/handalModalLogin', payload: { visible: false } })
      } else {
        const errorMessage = { message: '当前岗位不能登录，请联系管理员' }
        throw errorMessage
      }
    })
  }
  render () {
    const { visible, form: { getFieldDecorator } } = this.props
    const { confirmLoading, PostVisible, posts } = this.state
    const modalProps = {
      maskClosable: false,
      closable: false,
      visible,
      key: visible,
      width: 800,
      footer: null,
      bodyStyle: { padding: '0' },
      maskStyle: { 'background-color': 'rgba(55, 55, 55, 0.6)' },
      wrapClassName: 'login-modal-wrap',
    }
    const psotProps = {
      visible: PostVisible,
      posts,
      handlePostModal: this.handlePostModal,
    }
    return (
      <Modal {...modalProps} >
        <div className={styles['login-box']} >
          <div className={styles['login-bg']}>
            <div className={styles['bg-title']} >
              <span className={styles['bg-title-logo']}><img src="/hbz_logo.png" alt="货帮主logo" /></span>
              <span>货帮组物流平台</span>
            </div>
            <div className={styles['bg-content']} >
            成都货帮主网络科技有限公司成立于国家“互联网+”行动计划开局之年，致力于以互联网为依托下的运输能力资源池 ，打造成为高效率高水准的运输能力提供商。
            </div>
          </div>
          <div className={styles.form}>
            <div className={styles.logo}>
              <span>{config.name}</span>
            </div>
            <Form>
              <FormItem hasFeedback>
                {getFieldDecorator('loginName', {
                  rules: [
                    {
                      required: true,
                      message: '请输入登录账号',
                    },
                  ],
                })(
                  <Input size="large" onPressEnter={this.handleOk} placeholder="登录账号" />
                )}
              </FormItem>
              <FormItem hasFeedback>
                {getFieldDecorator('password', {
                  rules: [
                    {
                      required: true,
                      message: '请输入登录密码',
                    },
                  ],
                })(
                  <Input
                    size="large"
                    type="password"
                    onPressEnter={this.handleOk}
                    placeholder="登录密码"
                  />
                )}
              </FormItem>
              <Row>
                <Button
                  type="primary"
                  size="large"
                  onClick={this.handleOk}
                  loading={confirmLoading}
                >
                  登 录
                </Button>
              </Row>
            </Form>
          </div>
        </div>
        {PostVisible && <PostModal {...psotProps} />}
      </Modal>
    )
  }
}

const ModalLoginForm = Form.create()(ModalLogin)

ModalLogin.propTypes = {
  visible: PropTypes.bool,
  form: PropTypes.object,
  modalType: PropTypes.string,
  handleModal: PropTypes.func,
  userId: PropTypes.string,
  dispatch: PropTypes.func,
}
export default ModalLoginForm
