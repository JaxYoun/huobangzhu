import React from 'react'
import { Modal, Button, Icon } from 'antd'
import PropTypes from 'prop-types'
import styles from './postModal.less'

// const postModal = ({ visible, posts, dispatch }) => {


// }
class postModal extends React.Component {
  state = {}
  selectPost = (post) => {
    const { handlePostModal } = this.props
    handlePostModal(post)
  }
  handleCancel = () => {
    const { handlePostModal } = this.props
    handlePostModal({ visible: false })
  }

  render () {
    const { visible, posts } = this.props
    let postList = Array.from(posts).map(item => <Button className={styles.postItem} icon="user" onClick={this.selectPost.bind(this, item)}>{item.postName}</Button>)
    return (
      <Modal
        title={<div><Icon type="smile-o" /> 恭喜你，登录成功！请选择岗位</div>}
        wrapClassName="vertical-center-modal"
        visible={visible}
        onCancel={this.handleCancel.bind(this)}
        footer={null}
      >
        <div className={styles.postList}>
          {postList}
        </div>
      </Modal>
    )
  }
}
postModal.propTypes = {
  visible: PropTypes.bool.isRequired,
  posts: PropTypes.isRequired,
  handlePostModal: PropTypes.func,
}
export default postModal
